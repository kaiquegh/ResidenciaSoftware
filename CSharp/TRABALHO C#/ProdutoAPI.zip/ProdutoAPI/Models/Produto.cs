﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProdutoAPI.Models
{
    public class Produto
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Quantidade { get; set; }
        public string Valor { get; set; }

    }
}
